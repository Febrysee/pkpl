package com.example.apotek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
